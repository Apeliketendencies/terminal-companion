# Terminal AI Agent

A powerful terminal-based AI assistant with long-term memory powered by LanceDB and Ollama.

## Features
- **Intelligent Memory**: Uses LanceDB vector database to remember past conversations.
- **Code Execution**: Suggests bash commands and offers to execute them (with user confirmation).
- **CLI & Interactive Mode**: Run one-off requests or enter a persistent chat session.
- **Sudo Support**: Handles interactive sudo prompts for administrative tasks.

## Requirements
- `ollama`
- `lancedb`
- `pandas`
- `numpy`
- `requests`

## Setup
1. Copy `agent.py`, `ollama_client.py`, and `memory_manager.py` to your home directory or a dedicated folder.
2. Make `agent.py` executable: `chmod +x agent.py`.
3. Link to your bin: `ln -s $(pwd)/agent.py ~/.local/bin/agent`.

## Usage
```bash
# Interactive mode
agent

# Single request
agent "What's my favorate color?"
```
